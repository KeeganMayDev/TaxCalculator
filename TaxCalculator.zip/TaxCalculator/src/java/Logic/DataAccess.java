/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JApplet;

/**
 *
 * @author keeganmay
 */
@WebServlet("/DataAccess")
public class DataAccess extends HttpServlet {

    public DataAccess()
    {
        super();
        System.out.println("Servlet Instantiated. . .");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("Servlet doPost instantiated. .");
        String TaxYear = req.getParameter("TaxYear");
        String Age = req.getParameter("Age");
        String Monthly = req.getParameter("Monthly");
        String Annual = req.getParameter("Annual");
        String Earnings = req.getParameter("Earnings");
        String Members = req.getParameter("Members");
        System.out.println("Tax Year"+TaxYear + ", Age "+ Age + ", Monthly boolean: "+ Monthly + ",Annual Boolean "+ Annual + ", Earnings: "+ Earnings );
        
        //String Income, String Monthly , String Annual, String TaxYear, String Age , String Members
        Calculate calc = new Calculate(Earnings, Monthly, Annual, TaxYear, Age, Members);
        double MonthlyTax = calc.getMothlyTax();
        System.out.println("R"+MonthlyTax);
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        DecimalFormat df2 = new DecimalFormat(".##");
        String Title = "Contact Form Response";
        out.println("<!DOCTYPE html>\n" +
"<!--[if lt IE 7]>      <html class=\"no-js lt-ie9 lt-ie8 lt-ie7\"> <![endif]-->\n" +
"<!--[if IE 7]>         <html class=\"no-js lt-ie9 lt-ie8\"> <![endif]-->\n" +
"<!--[if IE 8]>         <html class=\"no-js lt-ie9\"> <![endif]-->\n" +
"<!--[if gt IE 8]><!--> \n" +
"<html class=\"no-js\"> <!--<![endif]-->\n" +
"    <head>\n" +
"        <meta charset=\"utf-8\">\n" +
"        <title>Result</title>\n" +
"        <meta name=\"description\" content=\"\">\n" +
"        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n" +
"        <link href=\"css/flexslider.min.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\"/>\n" +
"        <link href=\"css/line-icons.min.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\"/>\n" +
"        <link href=\"css/elegant-icons.min.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\"/>\n" +
"        <link href=\"css/lightbox.min.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\"/>\n" +
"        <link href=\"css/bootstrap.min.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\"/>\n" +
"        <link href=\"css/theme.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\"/>\n" +
"        <link href=\"css/custom.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\"/>\n" +
"        <!--[if gte IE 9]>\n" +
"        	<link rel=\"stylesheet\" type=\"text/css\" href=\"css/ie9.css\" />\n" +
"		<![endif]-->\n" +
"        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,400,300,600,700%7CRaleway:700' rel='stylesheet' type='text/css'>\n" +
"        <script src=\"js/modernizr-2.6.2-respond-1.1.0.min.js\"></script>\n" +
"    </head>\n" +
"    <body>\n" +
"    	<div class=\"loader\">\n" +
"    		<div class=\"spinner\">\n" +
"			  <div class=\"double-bounce1\"></div>\n" +
"			  <div class=\"double-bounce2\"></div>\n" +
"			</div>\n" +
"    	</div>\n" +
"				\n" +
"		<div class=\"nav-container\">\n" +
"			<nav class=\"contained-bar top-bar\">\n" +
"				<div class=\"container\">\n" +
"				\n" +
"					<div class=\"contained-wrapper\">\n" +
"					\n" +
"						<div class=\"row nav-menu\">\n" +
"							<div class=\"col-md-2 col-sm-3 columns\">\n" +
"							<img class=\"logo logo-light\" alt=\"Logo\" src=\"img/logo-light.png\">\n" +
"							<img class=\"logo logo-dark\" alt=\"Logo\" src=\"img/logo-dark.png\">\n" +
"						</div>\n" +
"					\n" +
"							<div class=\"col-md-10 col-sm-9 columns\">\n" +
"							<ul class=\"menu\">\n" +
"								<li><a href=\"#\">Home</a></li>\n" +
"								\n" +
"								\n" +
"								\n" +
"							</ul>\n" +
"		\n" +
"							<ul class=\"social-icons text-right\">\n" +
"								<li>\n" +
"									<a href=\"#\">\n" +
"										<i class=\"icon social_twitter\"></i>\n" +
"									</a>\n" +
"								</li>\n" +
"							\n" +
"								<li>\n" +
"									<a href=\"#\">\n" +
"										<i class=\"icon social_facebook\"></i>\n" +
"									</a>\n" +
"								</li>\n" +
"							\n" +
"								<li>\n" +
"									<a href=\"#\">\n" +
"										<i class=\"icon social_instagram\"></i>\n" +
"									</a>\n" +
"								</li>\n" +
"							</ul>\n" +
"						</div>\n" +
"						</div>\n" +
"					\n" +
"						<div class=\"mobile-toggle\">\n" +
"							<i class=\"icon icon_menu\"></i>\n" +
"						</div>\n" +
"						\n" +
"					</div>\n" +
"					\n" +
"				</div>\n" +
"				<div class=\"bottom-border\"></div>\n" +
"			</nav>\n" +
"		\n" +
"			\n" +
"		\n" +
"			\n" +
"		\n" +
"			\n" +
"		\n" +
"			\n" +
"		\n" +
"			\n" +
"		\n" +
"			\n" +
"		\n" +
"			\n" +
"		\n" +
"		</div>\n" +
"		\n" +
"		<div class=\"main-container\">\n" +
"		<section class=\"pricing-1 bg-secondary-1\">\n" +
"				<div class=\"container\">\n" +
"					<div class=\"row\">\n" +
"						<div class=\"col-sm-12 text-center\">\n" +
"							<h1 class=\"text-white\">PSIber Tax Overview :<br><br></h1>\n" +
"						</div>\n" +
"					</div>\n" +
"					\n" +
"					<div class=\"row clearfix pricing-tables\">\n" +
"						<div class=\"col-md-3 col-sm-6 no-pad-right\">\n" +
"							<div class=\"pricing-table\">\n" +
"								<div class=\"price\">\n" +
"									<span class=\"sub\"> </span>\n" +
"									<span class=\"amount\">Income</span>\n" +
"									<span class=\"sub\"> </span>\n" +
"								</div>\n" +
"								<ul class=\"features\">\n" +
"									<li><strong>Gross annual :</strong> R"+ df2.format(calc.IncomeAnnual)+"</li>\n" +
"									<li><strong>Gross Mothly :</strong> R"+ df2.format(calc.IncomeMonthly)+"</li>\n" +
                                                                       
"								</ul>\n" +
"								\n" +
"							</div>\n" +
"						</div>\n" +
"						\n" +
"						<div class=\"col-md-3 col-sm-6 no-pad\">\n" +
"							<div class=\"pricing-table\">\n" +
"								<div class=\"price\">\n" +
"									<span class=\"sub\"> </span>\n" +
"									<span class=\"amount\">Tax</span>\n" +
"									<span class=\"sub\"> </span>\n" +
"								</div>\n" +
"								<ul class=\"features\">\n" +
"									<li><strong>Annual total:</strong> R"+ (calc.getMothlyTax()*12)+"</li>\n" +
"									<li><strong>Monthly total:</strong> R"+ (df2.format(calc.getMothlyTax()))+"</li>\n" +

"								</ul>\n" +
"								\n" +
"							</div>\n" +
"						</div>\n" +
"						\n" +
"						<div class=\"col-md-3 col-sm-6 no-pad\">\n" +
"							<div class=\"pricing-table emphasis\">\n" +
"								<div class=\"price\">\n" +
"									<span class=\"sub\"> </span>\n" +
"									<span class=\"amount\">Credits</span>\n" +
"									<span class=\"sub\"> </span>\n" +
"								</div>\n" +
"								<ul class=\"features\">\n" +
"									<li><strong>Rebate :</strong> R"+ df2.format(calc.TaxRebate)+"</li>\n" +
"									<li><strong>Medical aid credit :</strong> R"+ df2.format(calc.MedicalCredit)+"</li>\n" +
"								</ul>\n" +
"								\n" +
"							</div>\n" +
"						</div>\n" +
"						\n" +
"						<div class=\"col-md-3 col-sm-6 no-pad-left\">\n" +
"							<div class=\"pricing-table\">\n" +
"								<div class=\"price\">\n" +
"									<span class=\"sub\"> </span>\n" +
"									<span class=\"amount\">Overview</span>\n" +
"									<span class=\"sub\"> </span>\n" +
"								</div>\n" +
"								<ul class=\"features\">\n" +
"									<li><strong>Annual :</strong> R"+ df2.format(calc.IncomeAnnual-(calc.getMothlyTax()*12))+"</li>\n" +
"									<li><strong>Monthly :</strong> R"+ df2.format(calc.IncomeMonthly -calc.getMothlyTax())+"</li>\n" +
"								</ul>\n" +
"								\n" +
"							</div>\n" +
"						</div>\n" +
"						\n" +
"						\n" +
"					</div>\n" +
"					\n" +
"				</div>\n" +
"			\n" +
"			</section>\n" +
"		</div>\n" +
"		\n" +
"		<div class=\"footer-container\">\n" +
"					\n" +
"			\n" +
"		\n" +
"			<footer class=\"short bg-secondary-1\">\n" +
"				<div class=\"container\">\n" +
"					<div class=\"row\">\n" +
"						<div class=\"col-sm-10\">\n" +
"							<span class=\"sub\">© Copyright 2017 &nbsp;Keegan may</span>\n" +
"							\n" +
"						</div>\n" +
"						\n" +
"						<div class=\"col-sm-2 text-right\">\n" +
"							<ul class=\"social-icons\">\n" +
"								<li>\n" +
"									<a href=\"#\">\n" +
"										<i class=\"icon icon-megaphone\"></i>\n" +
"									</a>\n" +
"								</li>\n" +
"								\n" +
"								<li>\n" +
"									<a href=\"#\">\n" +
"										<i class=\"icon social_facebook\"></i>\n" +
"									</a>\n" +
"								</li>\n" +
"							</ul>	\n" +
"						</div>\n" +
"					</div>\n" +
"				</div>\n" +
"			</footer>\n" +
"		</div>\n" +
"				\n" +
"		<script src=\"https://www.youtube.com/iframe_api\"></script>\n" +
"		<script src=\"js/jquery.min.js\"></script>\n" +
"        <script src=\"js/jquery.plugin.min.js\"></script>\n" +
"        <script src=\"js/bootstrap.min.js\"></script>\n" +
"        <script src=\"js/jquery.flexslider-min.js\"></script>\n" +
"        <script src=\"js/smooth-scroll.min.js\"></script>\n" +
"        <script src=\"js/skrollr.min.js\"></script>\n" +
"        <script src=\"js/spectragram.min.js\"></script>\n" +
"        <script src=\"js/scrollReveal.min.js\"></script>\n" +
"        <script src=\"js/isotope.min.js\"></script>\n" +
"        <script src=\"js/twitterFetcher_v10_min.js\"></script>\n" +
"        <script src=\"js/lightbox.min.js\"></script>\n" +
"        <script src=\"js/jquery.countdown.min.js\"></script>\n" +
"        <script src=\"js/scripts.js\"></script>\n" +
"    </body>\n" +
"</html>\n" +
"				");
        
    }

}
