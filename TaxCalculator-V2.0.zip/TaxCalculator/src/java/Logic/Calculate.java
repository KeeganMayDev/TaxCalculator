/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author keeganmay
 */
public class Calculate extends DataAccess {

    public double IncomeAnnual, IncomeMonthly, MonthlyTaxDeduction, TaxRebate, MedicalCredit;
    public String TaxYear;
    public String Age;
    public int members;
    public double Percentage;

    public Calculate(String Income, String Monthly, String Annual, String TaxYear, String Age, String Members) {
        try {
            if (Monthly.equals("1")) {
                IncomeMonthly = Double.valueOf(Income);
                IncomeAnnual = IncomeMonthly * 12;
            }

        } catch (NullPointerException e) {
            try {
                if (Annual.equals("2")) {
                    IncomeAnnual = Double.valueOf(Income);
                    IncomeMonthly = IncomeAnnual / 12;
                }
            } catch (NullPointerException e2) {
                    System.out.println("Error :" + e2.toString());
            }
        }

        this.TaxYear = TaxYear;
        this.Age = Age;
        System.out.println("members:" + Members);
        members = Integer.valueOf(Members);
    }
//0 – 188 000           18% of taxable income
//188 001 – 293 600     33 840 + 26% of taxable income above 188 000
//293 601 – 406 400     61 296 + 31% of taxable income above 293 600
//406 401 – 550 100     96 264 + 36% of taxable income above 406 400
//550 101 – 701 300     147 996 + 39% of taxable income above 550 100
//701 301 and above     206 964 + 41% of taxable income above 701 300
//    Taxable Income
// 0 – 189 880
// 189 881 – 296 540 296 541 – 410 460 410 461 – 555 600
// 555 601 – 708 310 708 311 – 1 500 000 1 500 001 and above
// Tax Rebates
// Rebate
// Primary
// Secondary (Persons 65 and older) Tertiary (Persons 75 and older)
// Tax Thresholds
// Age
// Below age 65 Age 65 to 75 Age 75 and over
// Medical Aid Tax Credits
// Rate of Tax
// 18% of taxable income
// 34 178 + 26% of taxable income above 189 880 61 910 + 31% of taxable income above 296 540 97 225 + 36% of taxable income above 410 460
//149 475 + 39% of taxable income above 555 600 209 032 + 41% of taxable income above 708 310 533 625 + 45% of taxable income above 1 500 000
//R13 635 R7 479 R2 493
//Tax Threshold
//R75 750 R117 300 R131 150

    public double getMothlyTax() {
        double MonthlyTax = 0;
        if (getThresold(ClassifyAge(Age), TaxYear, IncomeAnnual)) {
            MonthlyTax = (getTaxableIncome(TaxYear, IncomeAnnual) - getTaxRebates(ClassifyAge(Age), TaxYear)) / 12;
            MonthlyTax -= getMedicalAidCredits(members, TaxYear);
            return MonthlyTax;
        } else {
            return MonthlyTax;
        }

    }

    public double getTaxableIncome(String TaxYear, double IncomeAnnual) {
        double TaxableIncome = 0;
        int age = 0;
        switch (TaxYear) {
            case "2017":
                if (IncomeAnnual < 188000) {
                    TaxableIncome = IncomeAnnual * 0.18;
                    return TaxableIncome;
                } else if ((IncomeAnnual >= 188001) && (IncomeAnnual <= 293600)) {
                    TaxableIncome = 33840 + ((IncomeAnnual - 188000) * 0.26);
                    Percentage = 0.26;
                    return TaxableIncome;
                } else if ((IncomeAnnual >= 293601) && (IncomeAnnual <= 406400)) {
                    TaxableIncome = 61296 + ((IncomeAnnual - 293600) * 0.31);
                    Percentage = 0.31;
                    return TaxableIncome;
                } else if ((IncomeAnnual >= 406401) && (IncomeAnnual <= 550100)) {
                    TaxableIncome = 96264 + ((IncomeAnnual - 406400) * 0.36);
                    Percentage = 0.36;
                    return TaxableIncome;
                } else if ((IncomeAnnual >= 550101) && (IncomeAnnual <= 701300)) {
                    TaxableIncome = 147996 + ((IncomeAnnual - 550100) * 0.39);
                    Percentage = 0.39;
                    return TaxableIncome;
                } else if (IncomeAnnual >= 701301) {
                    TaxableIncome = 206964 + ((IncomeAnnual - 701300) * 0.41);
                    Percentage = 0.41;
                    return TaxableIncome;
                }

                break;

            case "2018":
                if (IncomeAnnual < 189880) {
                    TaxableIncome = IncomeAnnual * 0.18;
                    Percentage = 0.18;
                    return TaxableIncome;
                } else if ((IncomeAnnual >= 189881) && (IncomeAnnual <= 296540)) {
                    TaxableIncome = 34178 + ((IncomeAnnual - 189880) * 0.26);
                    Percentage = 0.26;
                    return TaxableIncome;
                } else if ((IncomeAnnual >= 296541) && (IncomeAnnual <= 410460)) {
                    TaxableIncome = 61910 + ((IncomeAnnual - 296540) * 0.31);
                    Percentage = 0.31;
                    return TaxableIncome;
                } else if ((IncomeAnnual >= 410461) && (IncomeAnnual <= 555600)) {
                    TaxableIncome = 97225 + ((IncomeAnnual - 410460) * 0.36);
                    Percentage = 0.36;
                    return TaxableIncome;
                } else if ((IncomeAnnual >= 555601) && (IncomeAnnual <= 708310)) {
                    TaxableIncome = 149475 + ((IncomeAnnual - 555600) * 0.39);
                    Percentage = 0.39;
                    return TaxableIncome;
                } else if ((IncomeAnnual >= 708311) && (IncomeAnnual <= 1500000)) {
                    TaxableIncome = 209032 + ((IncomeAnnual - 708310) * 0.41);
                    Percentage = 0.41;
                    return TaxableIncome;
                } else if ((IncomeAnnual >= 1500001)) {
                    TaxableIncome = 533625 + ((IncomeAnnual - 1500000) * 0.45);
                    Percentage = 0.45;
                    return TaxableIncome;
                }
                break;
        }

        return TaxableIncome;
    }

    public String ClassifyAge(String iAge) {
        if (iAge.equals("below 65")) {
            return "Secondary";
        } else if (iAge.equals("65 to 75")) {
            return "Tertiary";
        } else {
            return "Primary";
        }

    }

    public double getTaxRebates(String Age, String TaxYear) {
        double Rebate = 0;

        switch (TaxYear) {
            case "2017":
                Rebate = 13500;
                switch (Age) {
                    case "Secodary":
                        Rebate += 7407;
                    case "Tertiary":
                        Rebate += 2466;
                        break;
                }
                TaxRebate = Rebate;
                return Rebate;

            case "2018":
                Rebate = 13635;
                switch (Age) {
                    case "Secodary":
                        Rebate += 7479;
                    case "Tertiary":
                        Rebate += 2493;
                        break;
                }
                TaxRebate = Rebate;
                return Rebate;
        }
        TaxRebate = Rebate;
        return Rebate;
    }

    public double getMedicalAidCredits(int members, String TaxYear) {
        int val1 = 0, val2 = 0;
        switch (TaxYear) {
            case "2017":
                val1 = 286;
                val2 = 192;
                break;
            case "2018":
                val1 = 303;
                val2 = 204;
                break;
        }

        double MedicalAidCredit = 0;
        int iDependantsCredit = 2;
        for (int i = 0; i <= members; i++) {
            if (iDependantsCredit > 0) {
                MedicalAidCredit += val1;
                iDependantsCredit--;
            } else {
                MedicalAidCredit += val2;
            }
        }
        MedicalCredit = MedicalAidCredit;
        return MedicalAidCredit;
    }

    public boolean getThresold(String Age, String TaxYear, double IncomeAnnual) {
        boolean valid = true;
        switch (TaxYear) {
            case "2017":
                switch (Age) {
                    case "Primary":
                        if (IncomeAnnual < 75000) {
                            valid = false;
                        }
                        break;
                    case "Secodary":
                        if (IncomeAnnual < 116150) {
                            valid = false;
                        }
                        break;
                    case "Tertiary":
                        if (IncomeAnnual < 129850) {
                            valid = false;
                        }
                        break;
                }
                return valid;

            case "2018":
                switch (Age) {
                    case "Primary":
                        if (IncomeAnnual < 75750) {
                            valid = false;
                        }
                        break;
                    case "Secodary":
                        if (IncomeAnnual < 117300) {
                            valid = false;
                        }
                        break;
                    case "Tertiary":
                        if (IncomeAnnual < 131150) {
                            valid = false;
                        }
                        break;
                }
                return valid;

        }
        return true;
    }
}
